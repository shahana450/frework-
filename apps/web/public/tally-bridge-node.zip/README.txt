FreWork Tally Bridge
====================

1. In Tally Prime: F1 > Settings > Connectivity > turn on the HTTP server on port 7001.
2. Right-click this zip > Extract All. Open the extracted folder.
3. Double-click run-tally-bridge.bat and keep the window open while you use FreWork.
4. In FreWork, open your company in Tally and press "Connect to Tally".

Node.js is included (node\node.exe, version 22.11.0 from nodejs.org) - you don't need to install anything.
Node.js licence: node\LICENSE
