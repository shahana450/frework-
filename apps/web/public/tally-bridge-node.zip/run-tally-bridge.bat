@echo off
title FreWork Tally Bridge
color 0A
echo.
echo  ================================================
echo    FreWork Tally Bridge - Starting...
echo  ================================================
echo.

:: Node.js comes inside this folder (node\node.exe), so nothing needs installing.
:: If it's missing, an installed Node.js is used instead.
set "NODE=%~dp0node\node.exe"
if exist "%NODE%" goto run

where node >nul 2>&1
if %errorlevel% neq 0 (
  color 0C
  echo  ERROR: node\node.exe is missing from this folder.
  echo.
  echo  Extract the WHOLE zip (right-click - Extract All),
  echo  then double-click run-tally-bridge.bat inside the extracted folder.
  echo.
  pause
  exit /b 1
)
set "NODE=node"

:run
"%NODE%" "%~dp0tally-bridge.js"

echo.
echo  Bridge stopped.
pause
